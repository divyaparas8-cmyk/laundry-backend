const express = require('express');
const mongoose = require('mongoose');
const Order = require('../models/Order');
const Customer = require('../models/Customer');
const Payment = require('../models/Payment');
const Pickup = require('../models/Pickup');
const Delivery = require('../models/Delivery');
const User = require('../models/User');
const Driver = require('../models/Driver');
const Role = require('../models/Role');
const Branch = require('../models/Branch');
const Expense = require('../models/Expense');
const LaundryService = require('../models/LaundryService');
const { authenticate, requirePermission } = require('../middleware/auth');

const router = express.Router();

const resolveBranch = require('../utils/resolveBranch');

// Helper to attach targetBranchId and targetBranchObj to req
const attachBranchContext = async (req) => {
  const queryBranch = req.query.branchId || req.headers['x-selected-branch'] || req.headers['x-branch-id'];
  if (queryBranch && queryBranch !== 'All' && queryBranch !== 'all' && queryBranch !== 'undefined' && queryBranch !== 'null') {
    const branchDoc = await resolveBranch(queryBranch);
    req.targetBranchObj = branchDoc;
    req.targetBranchId = branchDoc ? branchDoc._id : null;
  } else if (req.user && req.user.role !== 'Super Admin' && req.user.branch) {
    req.targetBranchId = req.user.branch;
    const Branch = require('../models/Branch');
    req.targetBranchObj = await Branch.findById(req.user.branch);
  } else {
    req.targetBranchId = null;
    req.targetBranchObj = null;
  }
};

// Helper to apply branch filter based on user role and query parameter
const applyBranchFilter = (req, baseFilter = {}, isUser = false) => {
  const targetId = req.targetBranchId;
  const field = isUser ? 'branch' : 'branchId';

  if (targetId) {
    if (isUser) {
      return { ...baseFilter, branch: targetId };
    }
    return {
      ...baseFilter,
      $or: [
        { branchId: targetId },
        { branch: targetId },
        { sharedBranches: targetId },
        { transferredTo: targetId }
      ]
    };
  }

  return baseFilter;
};

// Helper for date range filter
const applyDateFilter = (start, end, dateField = 'date', baseFilter = {}) => {
  const filter = { ...baseFilter };
  if (start || end) {
    filter[dateField] = {};
    if (start) filter[dateField].$gte = start;
    if (end) filter[dateField].$lte = end;
  }
  return filter;
};

// Helper to normalize and map service names to official Laundry Services
const normalizeServiceName = (serviceType, dbServices = []) => {
  const s = String(serviceType || '').toLowerCase().trim();
  if (s.includes('express') && (s.includes('iron') || s.includes('press')) && (s.includes('wash') || s.includes('fold'))) {
    return 'Express Wash & Iron';
  }
  if (s.includes('express') && (s.includes('wash') || s.includes('fold'))) {
    return 'Express Wash & Iron';
  }
  if (s.includes('express') && (s.includes('iron') || s.includes('press'))) {
    return 'Express Ironing';
  }
  if (s.includes('wash') || s.includes('fold') || s.includes('normal wash')) {
    return 'Wash & Iron';
  }
  if (s.includes('iron') || s.includes('press')) {
    return 'Normal Ironing';
  }
  if (dbServices && dbServices.length > 0) {
    const matched = dbServices.find(dbS => (dbS.name || '').toLowerCase() === s);
    if (matched) return matched.name;
  }
  return serviceType || 'Wash & Iron';
};

// @route   GET /api/reports/dashboard
// @desc    Get metrics for dashboard charts and summaries
router.get('/dashboard', authenticate, requirePermission('view_reports'), async (req, res) => {
  try {
    await attachBranchContext(req);
    const { start, end } = req.query;
    
    // Build filters
    const orderFilter = applyBranchFilter(req, applyDateFilter(start, end, 'date'));
    const paymentFilter = applyBranchFilter(req, applyDateFilter(start, end, 'date'));
    const pickupFilter = applyBranchFilter(req, applyDateFilter(start, end, 'pickupDate'));
    const deliveryFilter = applyBranchFilter(req, applyDateFilter(start, end, 'deliveryDate'));
    
    const orders = await Order.find(orderFilter);
    const payments = await Payment.find(paymentFilter);
    const customers = await Customer.find(applyBranchFilter(req, {}, true));
    const pickups = await Pickup.find(pickupFilter);
    const deliveries = await Delivery.find(deliveryFilter);
    const users = await User.find(applyBranchFilter(req, {}, true)).populate('role');
    const dbServices = await LaundryService.find();
    
    const totalRevenue = orders.reduce((sum, o) => sum + (o.totalAmount || o.amount || 0), 0);
    const totalOrders = orders.length;
    const completedOrders = orders.filter(o => o.status === 'Delivered').length;
    
    const terminalStatuses = ['Delivered', 'Return', 'Cancelled', 'Store', 'In Store'];
    const pendingOrders = orders.filter(o => !terminalStatuses.includes(o.status)).length;
    
    const activeCustomers = customers.filter(c => c.status === 'Active').length;
    const averageOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;
    
    // Dynamic Service Revenue & Counts from DB Services
    const serviceRevenue = {};
    const defaultServices = dbServices.length > 0
      ? dbServices.map(s => s.name)
      : ['Normal Ironing', 'Wash & Iron', 'Express Ironing', 'Express Wash & Iron'];
      
    defaultServices.forEach(name => {
      serviceRevenue[name] = 0;
    });

    orders.forEach(o => {
      const sName = normalizeServiceName(o.serviceType || o.service, dbServices);
      const val = o.totalAmount || o.amount || 0;
      serviceRevenue[sName] = (serviceRevenue[sName] || 0) + val;
    });

    // Helper to normalize payment methods
    const normalizePaymentMethod = (method) => {
      const m = String(method || '').toLowerCase().trim();
      if (m === 'k-net' || m === 'knet' || m === 'card' || m === 'بطاقة' || m === 'شبكة') return 'K-Net';
      if (m === 'bukey' || m === 'bouquet' || m === 'باقة' || m === 'باقات' || m === 'package' || m === 'subscription') return 'Bukey';
      if (m === 'credit' || m === 'آجل' || m === 'ذمم' || m === 'unpaid' || m === 'غير مدفوع' || m === 'pending') return 'Credit';
      if (m === 'link' || m === 'رابط') return 'Link';
      return 'Cash';
    };

    // Real Payment Distribution from orders & payments in period
    const paymentDistribution = {
      Cash: 0,
      'K-Net': 0,
      Bukey: 0,
      Credit: 0
    };

    orders.forEach(o => {
      const isPaid = o.paymentStatus === 'Paid';
      const m = o.paymentMethod || (isPaid ? 'Cash' : 'Credit');
      const normMethod = normalizePaymentMethod(m);
      const amount = Number(o.totalAmount || o.amount || 0);
      if (paymentDistribution[normMethod] !== undefined) {
        paymentDistribution[normMethod] += amount;
      } else {
        paymentDistribution[normMethod] = amount;
      }
    });

    payments.forEach(p => {
      const isAlreadyInOrders = p.order && orders.some(o => o._id.toString() === p.order.toString());
      if (!isAlreadyInOrders) {
        const normMethod = normalizePaymentMethod(p.method);
        const amount = Number(p.amount || 0);
        if (paymentDistribution[normMethod] !== undefined) {
          paymentDistribution[normMethod] += amount;
        } else {
          paymentDistribution[normMethod] = amount;
        }
      }
    });

    // Payment method breakdown object
    const paymentMethodBreakdown = { ...paymentDistribution };

    // Order status breakdown object with official system statuses
    const orderStatusBreakdown = {
      Waiting: 0,
      'Preparing in shop': 0,
      'Preparing in workshop': 0,
      Hold: 0,
      Ready: 0,
      'Ready for delivery': 0,
      'Ready for shop': 0,
      'With Driver': 0,
      Delivered: 0,
      Return: 0,
      Store: 0
    };

    const normalizeOrderStatus = (status) => {
      const s = String(status || '').trim();
      const legacyMap = {
        Received: 'Waiting',
        'In Workshop': 'Preparing in workshop',
        'In Shop': 'Preparing in shop',
        'On Hold': 'Hold',
        'In Store': 'Store',
        'H Services': 'Ready for delivery',
        Cancel: 'Return',
        Cancelled: 'Return',
        Washing: 'Preparing in shop',
        Drying: 'Preparing in workshop',
        Ironing: 'Preparing in workshop',
      };
      return legacyMap[s] || s;
    };

    orders.forEach(o => {
      if (o.status) {
        const norm = normalizeOrderStatus(o.status);
        if (orderStatusBreakdown[norm] !== undefined) {
          orderStatusBreakdown[norm] += 1;
        } else {
          orderStatusBreakdown[norm] = 1;
        }
      }
    });

    // Previous Period calculations for growth
    let prevStart, prevEnd;
    if (start && end) {
      const s = new Date(start);
      const e = new Date(end);
      const diffTime = Math.abs(e - s);
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) || 30;
      
      const ps = new Date(s);
      ps.setDate(ps.getDate() - diffDays - 1);
      const pe = new Date(s);
      pe.setDate(pe.getDate() - 1);
      
      prevStart = ps.toISOString().split('T')[0];
      prevEnd = pe.toISOString().split('T')[0];
    } else {
      const s = new Date();
      s.setDate(s.getDate() - 30);
      const e = new Date();
      
      const ps = new Date();
      ps.setDate(ps.getDate() - 60);
      const pe = new Date();
      pe.setDate(pe.getDate() - 31);
      
      prevStart = ps.toISOString().split('T')[0];
      prevEnd = pe.toISOString().split('T')[0];
    }

    const prevOrderFilter = applyBranchFilter(req, applyDateFilter(prevStart, prevEnd, 'date'));
    const prevOrders = await Order.find(prevOrderFilter);
    const prevRevenue = prevOrders.reduce((sum, o) => sum + (o.totalAmount || o.amount || 0), 0);
    const prevOrdersCount = prevOrders.length;
    const prevCompletedOrders = prevOrders.filter(o => o.status === 'Delivered').length;
    const prevPendingOrders = prevOrders.filter(o => !terminalStatuses.includes(o.status)).length;
    const prevAverageOrderValue = prevOrdersCount > 0 ? prevRevenue / prevOrdersCount : 0;

    const currentRegisteredCustomers = customers.filter(c => {
      const regDate = c.registrationDate || c.createdAt;
      if (!regDate) return false;
      const dStr = typeof regDate === 'string' ? regDate : new Date(regDate).toISOString().split('T')[0];
      return dStr >= (start || '') && dStr <= (end || '');
    }).length;
    
    const prevRegisteredCustomers = customers.filter(c => {
      const regDate = c.registrationDate || c.createdAt;
      if (!regDate) return false;
      const dStr = typeof regDate === 'string' ? regDate : new Date(regDate).toISOString().split('T')[0];
      return dStr >= prevStart && dStr <= prevEnd;
    }).length;

    const getGrowthMetrics = (current, previous) => {
      if (previous === 0) {
        return { text: current > 0 ? '+100%' : '0%', positive: current >= 0 };
      }
      const val = ((current - previous) / previous) * 100;
      return { text: `${val >= 0 ? '+' : ''}${val.toFixed(1)}%`, positive: val >= 0 };
    };

    const growth = {
      revenue: getGrowthMetrics(totalRevenue, prevRevenue),
      orders: getGrowthMetrics(totalOrders, prevOrdersCount),
      completed: getGrowthMetrics(completedOrders, prevCompletedOrders),
      pending: getGrowthMetrics(pendingOrders, prevPendingOrders),
      customers: getGrowthMetrics(currentRegisteredCustomers, prevRegisteredCustomers),
      avgOrder: getGrowthMetrics(averageOrderValue, prevAverageOrderValue)
    };

    // Payment Analytics
    const paidAmount = orders.filter(o => o.paymentStatus === 'Paid').reduce((sum, o) => sum + (o.totalAmount || 0), 0);
    const pendingAmount = orders.filter(o => o.paymentStatus === 'Pending' || o.paymentStatus === 'Overdue').reduce((sum, o) => sum + (o.totalAmount || 0), 0);
    const partialAmount = orders.filter(o => o.paymentStatus === 'Partial').reduce((sum, o) => sum + (o.totalAmount || 0), 0);
    const dueCustomers = customers.filter(c => (c.balance || 0) > 0).length;

    const paymentsAnalytics = {
      paidAmount,
      pendingAmount,
      partialAmount,
      dueCustomers
    };

    // Home Service Analytics
    const totalPickups = pickups.length;
    const completedPickups = pickups.filter(p => p.status === 'Completed').length;
    const pendingPickups = Math.max(0, totalPickups - completedPickups);
    const totalDeliveries = deliveries.length;
    const completedDeliveries = deliveries.filter(d => d.status === 'Delivered').length;
    const pendingDeliveries = deliveries.filter(d => d.status !== 'Delivered' && d.status !== 'Failed').length;
    const failedDeliveries = deliveries.filter(d => d.status === 'Failed').length;

    const logisticsAnalytics = {
      totalPickups,
      completedPickups,
      pendingPickups,
      totalDeliveries,
      completedDeliveries,
      pendingDeliveries,
      failedDeliveries
    };

    // Top Customers
    const customerMap = {};
    orders.forEach(o => {
      const name = o.customerName || 'Unknown';
      if (!customerMap[name]) {
        customerMap[name] = {
          customerName: name,
          totalOrders: 0,
          totalRevenue: 0,
          lastOrderDate: o.date
        };
      }
      customerMap[name].totalOrders += 1;
      customerMap[name].totalRevenue += (o.totalAmount || 0);
      if (new Date(o.date) > new Date(customerMap[name].lastOrderDate)) {
        customerMap[name].lastOrderDate = o.date;
      }
    });
    const topCustomers = Object.values(customerMap)
      .sort((a, b) => b.totalRevenue - a.totalRevenue)
      .slice(0, 10);

    // Staff Performance
    const staffPerformance = users.map(u => {
      const userOrders = orders.filter(o => o.createdBy === u.name || o.createdBy === u.username);
      const userDeliveries = deliveries.filter(d => (d.assignedStaff === u.name || d.assignedStaff === u.username) && d.status === 'Delivered');
      
      const ordersHandledCount = userOrders.length;
      const deliveriesCompletedCount = userDeliveries.length;
      const revenueGeneratedSum = userOrders.reduce((sum, o) => sum + (o.totalAmount || 0), 0);
      
      return {
        staffName: u.name,
        role: u.role ? u.role.name : 'Staff',
        ordersHandled: ordersHandledCount,
        deliveriesCompleted: deliveriesCompletedCount,
        revenueGenerated: revenueGeneratedSum
      };
    });

    const todayStr = new Date().toISOString().split('T')[0];
    const todayOrders = orders.filter(o => o.date === todayStr);
    const todayPayments = payments.filter(p => p.date === todayStr);

    const todayPickups = pickups.filter(p => {
      const pDate = p.pickupDate || (p.createdAt ? new Date(p.createdAt).toISOString().split('T')[0] : '');
      return pDate === todayStr;
    });
    const todayDeliveries = deliveries.filter(d => {
      const dDate = d.deliveryDate || (d.createdAt ? new Date(d.createdAt).toISOString().split('T')[0] : '');
      return dDate === todayStr;
    });

    const pickupsAssignedToday = todayPickups.length;
    const pickupsCompletedToday = todayPickups.filter(p => p.status === 'Completed').length;
    const pickupsPendingToday = Math.max(0, pickupsAssignedToday - pickupsCompletedToday);

    const deliveriesAssignedToday = todayDeliveries.length;
    const deliveriesCompletedToday = todayDeliveries.filter(d => d.status === 'Delivered').length;
    const deliveriesPendingToday = todayDeliveries.filter(d => d.status !== 'Delivered' && d.status !== 'Failed').length;

    const daily = {
      revenueToday: todayOrders.reduce((sum, o) => sum + (o.totalAmount || 0), 0),
      ordersToday: todayOrders.length,
      paymentsReceived: todayPayments.reduce((sum, p) => sum + (p.amount || 0), 0),
      pickupsAssignedToday,
      pickupsCompletedToday,
      pickupsPendingToday,
      deliveriesAssignedToday,
      deliveriesCompletedToday,
      deliveriesPendingToday,
      totalTasksToday: pickupsAssignedToday + deliveriesAssignedToday,
      totalCompletedToday: pickupsCompletedToday + deliveriesCompletedToday,
      totalPendingToday: pickupsPendingToday + deliveriesPendingToday
    };

    const monthly = {
      monthlyRevenue: totalRevenue,
      revenueGrowth: growth.revenue,
      revenueComparison: prevRevenue
    };

    const ordersStats = {
      totalOrders: orders.length,
      pendingOrders: pendingOrders,
      deliveredOrders: completedOrders,
      cancelledOrders: orders.filter(o => o.status === 'Cancelled').length
    };

    res.json({
      summary: {
        totalRevenue,
        totalOrders,
        completedOrders,
        pendingOrders,
        activeCustomers,
        averageOrderValue,
        growth
      },
      periodOrders: orders,
      serviceRevenue,
      paymentDistribution,
      periodPayments: payments,
      paymentMethodBreakdown,
      orderStatusBreakdown,
      payments: paymentsAnalytics,
      logistics: logisticsAnalytics,
      topCustomers,
      staffPerformance,
      daily,
      monthly,
      orders: ordersStats
    });
  } catch (error) {
    console.error('Reports Dashboard Error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// @route   GET /api/reports/generate
// @desc    Generate specific tabular reports
router.get('/generate', authenticate, requirePermission('view_reports'), async (req, res) => {
  try {
    await attachBranchContext(req);
    const { reportType, category, parameter, start, end } = req.query;
    const orderFilter = applyBranchFilter(req, applyDateFilter(start, end, 'date'));
    
    let data = [];
    
    if (reportType === 'branch_sales') {
       const orders = await Order.find(applyDateFilter(start, end, 'date')).populate('branchId');
       const groups = {};
       orders.forEach(o => {
         const bName = o.branchId ? o.branchId.name : 'Unknown';
         if (req.targetBranchObj && bName.toLowerCase() !== req.targetBranchObj.name.toLowerCase()) {
            return;
         }
         if (req.user.role !== 'Super Admin' && req.user.branch !== (o.branchId && o.branchId._id.toString())) {
            return;
         }
         if (parameter && parameter !== 'All' && bName !== parameter) return;
         if (!groups[bName]) groups[bName] = { branch: bName, count: 0, revenue: 0 };
         groups[bName].count += 1;
         groups[bName].revenue += (o.totalAmount || 0);
       });
       data = Object.values(groups).map(g => ({
         ...g,
         avgValue: g.count > 0 ? g.revenue / g.count : 0
       }));
    }
    else if (reportType === 'total_sales') {
       const orders = await Order.find(orderFilter);
       const groups = {};
       orders.forEach(o => {
         if (!groups[o.date]) {
           groups[o.date] = { date: o.date, count: 0, subtotal: 0, discount: 0, tax: 0, total: 0 };
         }
         groups[o.date].count += 1;
         groups[o.date].subtotal += (Number(o.amount) || 0);
         groups[o.date].discount += (Number(o.discountAmount) || 0);
         groups[o.date].tax += (Number(o.tax) || 0);
         groups[o.date].total += (Number(o.totalAmount) || 0);
       });
       data = Object.values(groups).sort((a, b) => b.date.localeCompare(a.date));
    }
    else if (reportType === 'sales_detail') {
       const orders = await Order.find(orderFilter);
       orders.forEach(o => {
         const serviceLower = (o.serviceType || 'Normal').toLowerCase();
         const isExpress = serviceLower.includes('express');
         if (parameter === 'Express' && !isExpress) return;
         if (parameter === 'Normal' && isExpress) return;

         if (o.itemDetails) {
           o.itemDetails.forEach(it => {
             if (parameter && parameter !== 'All' && parameter !== 'Express' && parameter !== 'Normal' && it.name !== parameter) return;
             data.push({
               id: `${o.id}-${it.name}`,
               orderNo: o.number,
               customerName: o.customerName,
               date: o.date,
               itemName: it.name,
               service: o.serviceType || 'Normal',
               qty: it.quantity,
               price: it.unitPrice,
               total: it.quantity * it.unitPrice
             });
           });
         }
       });
    }
    else if (reportType === 'payment_methods') {
       const payments = await Payment.find(applyBranchFilter(req, applyDateFilter(start, end, 'date')));
       const groups = {};
       payments.forEach(p => {
         if (!groups[p.method]) groups[p.method] = { method: p.method, count: 0, collected: 0 };
         groups[p.method].count += 1;
         groups[p.method].collected += (Number(p.amount) || 0);
       });
       data = Object.values(groups);
    }
    else if (reportType === 'customer_list') {
       let customers = await Customer.find(applyBranchFilter(req, {}, true)).lean();
       if (parameter && parameter !== 'All') {
         customers = customers.filter(c => c._id.toString() === parameter);
       }

       // Aggregate actual order counts dynamically for each customer
       const customerIds = customers.map(c => c._id);
       const orderCounts = await Order.aggregate([
         { $match: { customer: { $in: customerIds } } },
         { $group: { _id: '$customer', count: { $sum: 1 } } }
       ]);
       const orderCountMap = {};
       orderCounts.forEach(oc => {
         if (oc._id) orderCountMap[oc._id.toString()] = oc.count;
       });

       data = customers.map(c => {
         const cId = c._id.toString();
         const validCustNo = (c.customerNo && c.customerNo !== 'Auto-generated') ? c.customerNo : '';
         const displayCustomerId = validCustNo ? `CUS-${validCustNo}` : `CUS-${cId.slice(-4).toUpperCase()}`;

         let discountDisplay = '0%';
         if (c.customDiscountRate !== undefined && c.customDiscountRate !== null && Number(c.customDiscountRate) > 0) {
           discountDisplay = `${c.customDiscountRate}%`;
         } else if (c.customerLevel && typeof c.customerLevel === 'string' && c.customerLevel.trim()) {
           discountDisplay = c.customerLevel.endsWith('%') ? c.customerLevel : `${c.customerLevel}%`;
         }

         return {
           id: c._id,
           customerId: displayCustomerId,
           customerNo: validCustNo || displayCustomerId,
           name: c.name,
           phone: c.phone,
           registered: c.registrationDate || c.createdAt,
           discount: discountDisplay,
           ordersCount: orderCountMap[cId] || c.invoicesCount || 0,
           balance: c.balance || 0
         };
       });
    }
    else if (reportType === 'top_customers') {
       const orders = await Order.find(orderFilter);
       const map = {};
       orders.forEach(o => {
          const key = o.customerName || 'Unknown';
          if (!map[key]) map[key] = { name: key, ordersCount: 0, spent: 0, lastDate: o.date };
          map[key].ordersCount += 1;
          map[key].spent += (o.totalAmount || 0);
          if (new Date(o.date) > new Date(map[key].lastDate)) map[key].lastDate = o.date;
       });
       let arr = Object.values(map).sort((a, b) => b.spent - a.spent);
       if (parameter && parameter !== 'All') {
          const cust = await Customer.findById(parameter);
          if (cust) arr = arr.filter(c => c.name === cust.name);
       }
       data = arr.map((c, i) => ({ id: i+1, ...c }));
    }
    else if (reportType === 'customer_debts') {
       let customers = await Customer.find(applyBranchFilter(req, { balance: { $gt: 0 } }, true)).sort({ balance: -1 }).lean();
       if (parameter && parameter !== 'All') {
         customers = customers.filter(c => c._id.toString() === parameter);
       }
       data = customers.map(c => {
         const cId = c._id.toString();
         const validCustNo = (c.customerNo && c.customerNo !== 'Auto-generated') ? c.customerNo : '';
         const displayCustomerId = validCustNo ? `CUS-${validCustNo}` : `CUS-${cId.slice(-4).toUpperCase()}`;

         return {
           id: c._id,
           customerId: displayCustomerId,
           customerNo: validCustNo || displayCustomerId,
           name: c.name,
           phone: c.phone,
           registered: c.registrationDate || c.createdAt,
           balance: c.balance
         };
       });
    }
    else if (reportType === 'completed_jobs' || reportType === 'pending_jobs') {
       const isCompleted = reportType === 'completed_jobs';
       let pFilter = applyDateFilter(start, end, 'pickupDate');
       let dFilter = applyDateFilter(start, end, 'deliveryDate');
       if (isCompleted) {
         pFilter.status = 'Completed';
         dFilter.status = 'Delivered';
       } else {
         pFilter.status = { $ne: 'Completed' };
         dFilter.status = { $ne: 'Delivered' };
       }
        const pickups = await Pickup.find(applyBranchFilter(req, pFilter));
        const deliveries = await Delivery.find(applyBranchFilter(req, dFilter));
       const items = [];
       pickups.forEach(p => items.push({ 
         id: `PKP-${p._id}`, reqId: p.pickupId || `PKP-${p._id}`, type: 'Pickup', 
         customer: p.customer, date: p.pickupDate, driver: p.assignedStaff || 'Unassigned', status: p.status 
       }));
       deliveries.forEach(d => items.push({ 
         id: `DEL-${d._id}`, reqId: d.deliveryId || `DEL-${d._id}`, type: 'Delivery', 
         customer: d.customer, date: d.deliveryDate, driver: d.assignedStaff || 'Unassigned', status: d.status 
       }));
       data = items.sort((a, b) => b.date.localeCompare(a.date));
    }
    else if (reportType === 'user_sales') {
       const orders = await Order.find(orderFilter);
       const expenses = await Expense.find(applyBranchFilter(req, applyDateFilter(start, end, 'date')));
       const customers = await Customer.find(applyBranchFilter(req, applyDateFilter(start, end, 'createdAt')));

       const groups = {};
       const getGroup = (name) => {
         const u = name || 'Counter Staff';
         if (!groups[u]) {
           groups[u] = {
             name: u,
             count: 0,
             sales: 0,
             cashCollected: 0,
             knetCollected: 0,
             bukeyCollected: 0,
             creditPending: 0,
             cashExpenses: 0,
             netCashInHand: 0,
             newCustomers: 0,
             subscribersAcquired: 0
           };
         }
         return groups[u];
       };

       orders.forEach(o => {
         const u = o.createdBy || 'Staff';
         if (parameter && parameter !== 'All' && u !== parameter) return;
         const grp = getGroup(u);
         grp.count += 1;
         grp.sales += (Number(o.totalAmount) || 0);

         const m = (o.paymentMethod || '').toLowerCase();
         const isPaid = o.paymentStatus === 'Paid';
         const isPartial = o.paymentStatus === 'Partial';
         const paid = o.amountPaid !== undefined && o.amountPaid !== null && Number(o.amountPaid) > 0
           ? Number(o.amountPaid)
           : (isPaid ? Number(o.totalAmount || 0) : 0);
         const tot = Number(o.totalAmount || 0);

         if (paid > 0) {
           if (/k-net|knet|card|بطاقة|شبكة|link/.test(m)) grp.knetCollected += paid;
           else if (/bukey|bouquet|باقة|package|subscription/.test(m)) grp.bukeyCollected += paid;
           else if (/unpaid|pending|credit|آجل/.test(m) && !isPaid) { /* credit */ }
           else grp.cashCollected += paid;
         }

         if (o.paymentStatus === 'Pending' || /credit|آجل|unpaid|pending|غير مدفوع/.test(m)) {
           grp.creditPending += (tot > paid ? tot - paid : tot);
         } else if (isPartial && tot > paid) {
           grp.creditPending += (tot - paid);
         }
       });

       expenses.forEach(e => {
         const u = e.createdBy || 'Staff';
         if (groups[u] && /cash|نقدي/i.test(e.paymentMethod || '')) {
           groups[u].cashExpenses += (Number(e.amount) || 0);
         }
       });

       customers.forEach(c => {
         const u = c.createdBy || 'Counter Staff';
         if (groups[u]) {
           groups[u].newCustomers += 1;
           if (c.isSubscriber || Number(c.insuranceAmount || 0) >= 20) {
             groups[u].subscribersAcquired += 1;
           }
         }
       });

       Object.values(groups).forEach(g => {
         g.netCashInHand = Math.max(0, g.cashCollected - g.cashExpenses);
       });

       data = Object.values(groups);
    }
    else if (reportType === 'area_sales') {
       const customers = await Customer.find(applyBranchFilter(req, {}, true));
       const orders = await Order.find(orderFilter);
       const areaMap = {};

       customers.forEach(c => {
         const area = (c.areaName || 'General / غير محدد').trim();
         if (parameter && parameter !== 'All' && area !== parameter) return;
         if (!areaMap[area]) {
           areaMap[area] = { area, customerCount: 0, subscriberCount: 0, orderCount: 0, totalSales: 0 };
         }
         areaMap[area].customerCount += 1;
         if (c.isSubscriber || Number(c.insuranceAmount || 0) >= 20) {
           areaMap[area].subscriberCount += 1;
         }
       });

       orders.forEach(o => {
         const cust = customers.find(c => String(c._id) === String(o.customer) || c.name === o.customerName);
         const area = (cust?.areaName || 'General / غير محدد').trim();
         if (parameter && parameter !== 'All' && area !== parameter) return;
         if (!areaMap[area]) {
           areaMap[area] = { area, customerCount: 0, subscriberCount: 0, orderCount: 0, totalSales: 0 };
         }
         areaMap[area].orderCount += 1;
         areaMap[area].totalSales += (Number(o.totalAmount) || 0);
       });

       data = Object.values(areaMap).sort((a, b) => b.totalSales - a.totalSales);
    }
    else if (reportType === 'shift_settlement') {
        const orders = await Order.find(orderFilter);
        const payments = await Payment.find(applyBranchFilter(req, applyDateFilter(start, end, 'date')));
        const expenses = await Expense.find(applyBranchFilter(req, applyDateFilter(start, end, 'date')));

        // Helper to determine shift: Morning (10:00 AM - 10:00 PM / 10:00 - 22:00), Evening (10:00 PM - 10:00 AM / 22:00 - 10:00)
        const getItemShift = (item) => {
          if (item.shift === 'Morning' || item.shift === 'Evening') return item.shift;
          if (item.time && typeof item.time === 'string') {
            const timeMatch = item.time.match(/(\d{1,2}):(\d{2})(?:\s*([ap]m))?/i);
            if (timeMatch) {
              let h = parseInt(timeMatch[1], 10);
              const ampm = timeMatch[3];
              if (ampm) {
                if (ampm.toLowerCase() === 'pm' && h < 12) h += 12;
                if (ampm.toLowerCase() === 'am' && h === 12) h = 0;
              }
              return (h >= 10 && h < 22) ? 'Morning' : 'Evening';
            }
          }
          const created = new Date(item.createdAt || item.date);
          if (!isNaN(created.getTime())) {
            const hour = created.getHours();
            return (hour >= 10 && hour < 22) ? 'Morning' : 'Evening';
          }
          return 'Morning';
        };

        // Filter items if user selected Morning or Evening specifically
        const filterByShiftParam = (item) => {
          if (!parameter || parameter === 'All' || parameter === 'All Day') return true;
          return getItemShift(item) === parameter;
        };

        const filteredOrders = orders.filter(filterByShiftParam);
        const filteredPayments = payments.filter(filterByShiftParam);
        const filteredExpenses = expenses.filter(filterByShiftParam);

        // Group orders by shift and staff
        // Key: `${shift}_${staffName}`
        const groups = {};

        filteredOrders.forEach((o) => {
          const shift = getItemShift(o);
          const staffName = o.createdBy || o.staffName || 'Counter Staff';
          const groupKey = `${shift}___${staffName}`;

          if (!groups[groupKey]) {
            groups[groupKey] = {
              shiftKey: shift,
              shift: shift === 'Morning' ? 'Morning' : 'Evening',
              staffName: staffName,
              invoicesCount: 0,
              totalRevenue: 0,
              cashCollected: 0,
              knetCollected: 0,
              bukeyCollected: 0,
              creditCollected: 0,
              cashExpenses: 0,
              netCashInHand: 0,
            };
          }

          groups[groupKey].invoicesCount += 1;
          const tot = Number(o.totalAmount || 0);
          groups[groupKey].totalRevenue += tot;

          const m = (o.paymentMethod || '').toLowerCase();
          const isPaid = o.paymentStatus === 'Paid';
          const isPartial = o.paymentStatus === 'Partial';
          const paid = o.amountPaid !== undefined && o.amountPaid !== null && Number(o.amountPaid) > 0
            ? Number(o.amountPaid)
            : (isPaid ? tot : 0);

          if (paid > 0) {
            if (/k-net|knet|card|بطاقة|شبكة|link/.test(m)) {
              groups[groupKey].knetCollected += paid;
            } else if (/bukey|bouquet|باقة|package|subscription/.test(m)) {
              groups[groupKey].bukeyCollected += paid;
            } else if (/unpaid|pending|credit|آجل/.test(m) && !isPaid) {
              // credit
            } else {
              groups[groupKey].cashCollected += paid;
            }
          }

          if (o.paymentStatus === 'Pending' || /credit|آجل|unpaid|pending|غير مدفوع/.test(m)) {
            groups[groupKey].creditCollected += (tot > paid ? tot - paid : tot);
          } else if (isPartial && tot > paid) {
            groups[groupKey].creditCollected += (tot - paid);
          }
        });

        // Account for cash expenses per staff/shift
        filteredExpenses.forEach((e) => {
          const shift = getItemShift(e);
          const staffName = e.createdBy || 'Counter Staff';
          const groupKey = `${shift}___${staffName}`;
          if (!groups[groupKey]) {
            groups[groupKey] = {
              shiftKey: shift,
              shift: shift === 'Morning' ? 'Morning' : 'Evening',
              staffName: staffName,
              invoicesCount: 0,
              totalRevenue: 0,
              cashCollected: 0,
              knetCollected: 0,
              bukeyCollected: 0,
              creditCollected: 0,
              cashExpenses: 0,
              netCashInHand: 0,
            };
          }
          if (!e.paymentMethod || /cash|نقدي/i.test(e.paymentMethod || '')) {
            groups[groupKey].cashExpenses += (Number(e.amount) || 0);
          }
        });

        // Compute netCashInHand for each group
        Object.values(groups).forEach((g) => {
          g.netCashInHand = Math.max(0, g.cashCollected - g.cashExpenses);
        });

        // Sort groups: Morning shifts first, then Evening shifts
        const staffRows = Object.values(groups).sort((a, b) => {
          if (a.shiftKey === b.shiftKey) return a.staffName.localeCompare(b.staffName);
          return a.shiftKey === 'Morning' ? -1 : 1;
        });

        // Calculate Grand Totals across all filtered items
        const totalInvoices = staffRows.reduce((sum, r) => sum + r.invoicesCount, 0);
        const totalRevenue = staffRows.reduce((sum, r) => sum + r.totalRevenue, 0);
        const totalCash = staffRows.reduce((sum, r) => sum + r.cashCollected, 0);
        const totalKnet = staffRows.reduce((sum, r) => sum + r.knetCollected, 0);
        const totalBukey = staffRows.reduce((sum, r) => sum + r.bukeyCollected, 0);
        const totalCredit = staffRows.reduce((sum, r) => sum + r.creditCollected, 0);
        const totalCashExpenses = staffRows.reduce((sum, r) => sum + r.cashExpenses, 0);
        const totalNetCash = Math.max(0, totalCash - totalCashExpenses);

        const morningStaffNames = [...new Set(staffRows.filter((r) => r.shiftKey === 'Morning').map((r) => r.staffName))];
        const eveningStaffNames = [...new Set(staffRows.filter((r) => r.shiftKey === 'Evening').map((r) => r.staffName))];

        const summaryRow = {
          shift: 'TOTAL',
          staffName: 'All Counter Staff',
          invoicesCount: totalInvoices,
          totalRevenue: totalRevenue,
          cashCollected: totalCash,
          knetCollected: totalKnet,
          bukeyCollected: totalBukey,
          creditCollected: totalCredit,
          cashExpenses: totalCashExpenses,
          netCashInHand: totalNetCash,
          isTotalRow: true,
          morningStaff: morningStaffNames,
          eveningStaff: eveningStaffNames,
          staffBreakdown: staffRows,
          expensesBreakdown: filteredExpenses.map((e) => ({
            id: e._id,
            title: e.title,
            amount: e.amount,
            category: e.category,
            paymentMethod: e.paymentMethod,
            time: e.time,
            createdBy: e.createdBy,
          })),
        };

        // Combine staff rows + summary total row
        data = staffRows.length > 0 ? [...staffRows, summaryRow] : [summaryRow];
    }
    else if (reportType === 'driver_income') {
       let driverQuery = {};
       if (req.targetBranchObj) {
         driverQuery.branch = req.targetBranchObj.name;
       } else if (req.targetBranchId) {
         const Branch = require('../models/Branch');
         const branchObj = await Branch.findById(req.targetBranchId);
         if (branchObj) driverQuery.branch = branchObj.name;
       }

       let drivers = await Driver.find(driverQuery);
       if (parameter && parameter !== 'All') {
         drivers = drivers.filter(d => d.driverName === parameter);
       }
       const activePickups = await Pickup.find({ status: { $ne: 'Completed' } });
       const activeDeliveries = await Delivery.find({ status: { $nin: ['Delivered', 'Failed'] } });

       // Fetch all completed jobs in range to perform sales revenue aggregates
       const completedDels = await Delivery.find({
         status: 'Delivered',
         ...applyDateFilter(start, end, 'deliveryDate')
       });
       const completedPups = await Pickup.find({
         status: 'Completed',
         ...applyDateFilter(start, end, 'pickupDate')
       });

       const allOrderNumbers = [
         ...completedDels.map(cd => cd.orderNumber),
         ...completedPups.map(cp => cp.orderNumber)
       ].filter(Boolean);
       const allOrders = await Order.find({ number: { $in: allOrderNumbers } });

       data = drivers.map(d => {
         const rawAreas = d.areas || (d.area ? [d.area] : []);
         const driverAreas = rawAreas.flatMap(a => typeof a === 'string' ? a.split(',').map(s => s.trim()) : a)
                                     .filter(a => a && a !== '...' && a !== '…');
         const pCount = activePickups.filter(p => p.assignedStaff === d.driverName).length;
         const dCount = activeDeliveries.filter(del => del.assignedStaff === d.driverName).length;

         const driverDels = completedDels.filter(cd => cd.assignedStaff === d.driverName);
         const driverPups = completedPups.filter(cp => cp.assignedStaff === d.driverName);
         const driverOrderNums = [
           ...driverDels.map(cd => cd.orderNumber),
           ...driverPups.map(cp => cp.orderNumber)
         ].filter(Boolean);

         const driverOrders = allOrders.filter(o => driverOrderNums.includes(o.number));
         const totalSales = driverOrders.reduce((sum, o) => sum + (o.totalAmount || 0), 0);
         const jobsCount = driverDels.length + driverPups.length;

         return {
           id: d._id,
           name: d.driverName,
           areas: driverAreas.join(', ') || '—',
           status: d.status || 'Available',
           activePickups: pCount,
           activeDeliveries: dCount,
           count: jobsCount,
           sales: totalSales
         };
       });
    }
    else if (reportType === 'driver_daily_report') {
       let driverQuery = {};
       if (req.targetBranchObj) {
         driverQuery.branch = req.targetBranchObj.name;
       } else if (req.targetBranchId) {
         const Branch = require('../models/Branch');
         const branchObj = await Branch.findById(req.targetBranchId);
         if (branchObj) driverQuery.branch = branchObj.name;
       }

       let drivers = await Driver.find(driverQuery).populate({ path: 'user', populate: { path: 'branch branches' } });
       if (parameter && parameter !== 'All') {
         drivers = drivers.filter(d => d.driverName === parameter);
       }

       const pFilter = applyDateFilter(start, end, 'pickupDate');
       const dFilter = applyDateFilter(start, end, 'deliveryDate');

       const periodPickups = await Pickup.find(applyBranchFilter(req, pFilter));
       const periodDeliveries = await Delivery.find(applyBranchFilter(req, dFilter));

       const dateDisplay = (start && end && start === end)
         ? start
         : (start && end ? `${start} to ${end}` : (start || end || 'All Dates'));

       const driverRows = drivers.map(d => {
         let branchName = d.branch || 'Home Service';
         if (/shoe|shoes|carpet/i.test(branchName)) {
           branchName = 'Home Service';
         }
         if (d.user && d.user.branch && d.user.branch.name) {
           const ubName = d.user.branch.name;
           if (!/shoe|shoes|carpet/i.test(ubName)) {
             branchName = ubName;
           }
         }

         const dPickups = periodPickups.filter(p => p.assignedStaff === d.driverName);
         const dDeliveries = periodDeliveries.filter(del => del.assignedStaff === d.driverName);

         const pickupsAssigned = dPickups.length;
         const pickupsCompleted = dPickups.filter(p => p.status === 'Completed').length;
         const pickupsPending = Math.max(0, pickupsAssigned - pickupsCompleted);

         const deliveriesAssigned = dDeliveries.length;
         const deliveriesCompleted = dDeliveries.filter(del => del.status === 'Delivered').length;
         const deliveriesPending = dDeliveries.filter(del => del.status !== 'Delivered' && del.status !== 'Failed').length;

         const totalTasks = pickupsAssigned + deliveriesAssigned;
         const completedTasks = pickupsCompleted + deliveriesCompleted;
         const pendingTasks = pickupsPending + deliveriesPending;

         return {
           id: d._id,
           driverName: d.driverName,
           branch: branchName,
           date: dateDisplay,
           totalPickups: pickupsAssigned,
           pickupsCompleted,
           pickupsPending,
           totalDeliveries: deliveriesAssigned,
           deliveriesCompleted,
           deliveriesPending,
           totalTasks,
           completedTasks,
           pendingTasks
         };
       });

       const totalPickupsAssigned = driverRows.reduce((s, r) => s + r.totalPickups, 0);
       const totalPickupsCompleted = driverRows.reduce((s, r) => s + r.pickupsCompleted, 0);
       const totalPickupsPending = driverRows.reduce((s, r) => s + r.pickupsPending, 0);
       const totalDeliveriesAssigned = driverRows.reduce((s, r) => s + r.totalDeliveries, 0);
       const totalDeliveriesCompleted = driverRows.reduce((s, r) => s + r.deliveriesCompleted, 0);
       const totalDeliveriesPending = driverRows.reduce((s, r) => s + r.deliveriesPending, 0);
       const totalAllTasks = totalPickupsAssigned + totalDeliveriesAssigned;
       const totalAllCompleted = totalPickupsCompleted + totalDeliveriesCompleted;
       const totalAllPending = totalPickupsPending + totalDeliveriesPending;

       const summaryRow = {
         id: 'TOTAL',
         driverName: 'TOTAL',
         branch: 'All Branches',
         date: dateDisplay,
         totalPickups: totalPickupsAssigned,
         pickupsCompleted: totalPickupsCompleted,
         pickupsPending: totalPickupsPending,
         totalDeliveries: totalDeliveriesAssigned,
         deliveriesCompleted: totalDeliveriesCompleted,
         deliveriesPending: totalDeliveriesPending,
         totalTasks: totalAllTasks,
         completedTasks: totalAllCompleted,
         pendingTasks: totalAllPending,
         isTotalRow: true
       };

       data = driverRows.length > 0 ? [...driverRows, summaryRow] : [summaryRow];
    }
    else if (reportType === 'home_delivery_report') {
       const baseOrderFilter = {
         $or: [
           { deliveryType: 'Home Delivery' },
           { deliveryDate: { $exists: true, $ne: '' } }
         ]
       };
       const filterWithDate = applyDateFilter(start, end, 'deliveryDate', baseOrderFilter);
       const orderFilterDeliv = applyBranchFilter(req, filterWithDate);

       const orders = await Order.find(orderFilterDeliv).populate('customer').lean();
       const orderNumbers = orders.map(o => o.number).filter(Boolean);
       const deliveries = await Delivery.find({ orderNumber: { $in: orderNumbers } }).lean();

       const delivMap = {};
       deliveries.forEach(d => {
         if (d.orderNumber) delivMap[d.orderNumber] = d;
       });

       const rows = orders.map(o => {
         const c = o.customer || {};
         const validCustNo = (c.customerNo && c.customerNo !== 'Auto-generated') ? c.customerNo : '';
         const custIdStr = c._id ? c._id.toString() : '';
         const displayCustomerId = validCustNo ? `CUS-${validCustNo}` : (custIdStr ? `CUS-${custIdStr.slice(-4).toUpperCase()}` : 'CUS-N/A');

         const dDoc = delivMap[o.number] || {};
         const isPaid = o.paymentStatus === 'Paid';
         const isPartial = o.paymentStatus === 'Partial';
         const total = Number(o.totalAmount || o.amount || 0);
         const paid = Number(o.amountPaid || (isPaid ? total : 0));
         const unpaid = Math.max(0, total - paid);

         let paymentStatusDisplay = 'Unpaid';
         let paymentStatusRaw = 'Unpaid';
         if (isPaid) {
           paymentStatusDisplay = 'Paid';
           paymentStatusRaw = 'Paid';
         } else if (isPartial && paid > 0) {
           paymentStatusDisplay = `Partial (Unpaid: ${unpaid.toFixed(3)})`;
           paymentStatusRaw = 'Partial';
         } else {
           paymentStatusDisplay = 'Unpaid';
           paymentStatusRaw = 'Unpaid';
         }

         const isSubscribed = Boolean(c.isSubscriber || Number(c.insuranceAmount || 0) >= 20);
         const subscriptionStatus = isSubscribed ? 'Subscribed ⭐' : 'Unsubscribed';

         const addressStr = dDoc.address || [c.street, c.partNo ? `Block ${c.partNo}` : '', c.jadda ? `Jadda ${c.jadda}` : '', c.houseNo ? `House ${c.houseNo}` : ''].filter(Boolean).join(', ') || 'Home Delivery';
         const areaStr = dDoc.areaName || c.areaName || '—';
         const driverStr = dDoc.assignedStaff || 'Unassigned';

         return {
           id: o._id,
           date: o.deliveryDate || o.date,
           customerName: o.customerName || c.name || 'Unknown',
           customerId: displayCustomerId,
           invoiceNumber: o.number,
           paymentStatus: paymentStatusDisplay,
           paymentStatusRaw: paymentStatusRaw,
           totalAmount: total,
           amountPaid: paid,
           unpaidAmount: unpaid,
           homeDeliveryDetails: `${areaStr} | ${addressStr} (Driver: ${driverStr})`,
           address: addressStr,
           area: areaStr,
           driver: driverStr,
           subscriptionStatus: subscriptionStatus,
           isSubscriber: isSubscribed
         };
       });

       let filteredRows = rows;
       if (parameter && parameter !== 'All') {
         if (parameter === 'Paid') filteredRows = rows.filter(r => r.paymentStatusRaw === 'Paid');
         else if (parameter === 'Unpaid') filteredRows = rows.filter(r => r.paymentStatusRaw === 'Unpaid');
         else if (parameter === 'Partial') filteredRows = rows.filter(r => r.paymentStatusRaw === 'Partial');
         else if (parameter === 'Subscribed') filteredRows = rows.filter(r => r.isSubscriber);
         else if (parameter === 'Unsubscribed') filteredRows = rows.filter(r => !r.isSubscriber);
       }

       data = filteredRows.sort((a, b) => b.date.localeCompare(a.date));
    }
    else if (reportType === 'subscriber_report') {
       let customers = await Customer.find(applyBranchFilter(req, {}, true)).lean();
       const customerIds = customers.map(c => c._id);
       const orderCounts = await Order.aggregate([
         { $match: { customer: { $in: customerIds } } },
         { $group: { _id: '$customer', count: { $sum: 1 }, totalSpent: { $sum: '$totalAmount' } } }
       ]);
       const statsMap = {};
       orderCounts.forEach(oc => {
         if (oc._id) statsMap[oc._id.toString()] = { count: oc.count, totalSpent: oc.totalSpent || 0 };
       });

       const allRows = customers.map(c => {
         const cId = c._id.toString();
         const validCustNo = (c.customerNo && c.customerNo !== 'Auto-generated') ? c.customerNo : '';
         const displayCustomerId = validCustNo ? `CUS-${validCustNo}` : `CUS-${cId.slice(-4).toUpperCase()}`;

         const isSubscribed = Boolean(c.isSubscriber || Number(c.insuranceAmount || 0) >= 20);
         const cStats = statsMap[cId] || { count: c.invoicesCount || 0, totalSpent: c.totalSpent || 0 };

         return {
           id: c._id,
           customerId: displayCustomerId,
           name: c.name,
           phone: c.phone,
           area: c.areaName || '—',
           subscriptionStatus: isSubscribed ? 'Subscribed' : 'Unsubscribed',
           isSubscriber: isSubscribed,
           page: isSubscribed ? 1 : 2,
           pageSection: isSubscribed ? 'Page 1: Subscribed Customers' : 'Page 2: Unsubscribed Customers',
           totalOrders: cStats.count,
           totalSpent: cStats.totalSpent,
           balance: c.balance || 0,
           registered: c.registrationDate || c.createdAt
         };
       });

       if (parameter === 'Subscribed') {
         data = allRows.filter(r => r.isSubscriber);
       } else if (parameter === 'Unsubscribed') {
         data = allRows.filter(r => !r.isSubscriber);
       } else {
         data = allRows.sort((a, b) => (b.isSubscriber ? 1 : 0) - (a.isSubscriber ? 1 : 0));
       }
    }
    else if (reportType === 'workshop_perf') {
       const allUsers = await User.find({}).populate('role');
       let users = allUsers;
       
       if (parameter && parameter !== 'All') {
         users = users.filter(u => u.name === parameter);
       }
       const orders = await Order.find(orderFilter);

       data = users.map(u => {
         const washedOrders = orders.filter(o => o.workshopTasks && o.workshopTasks.washedBy === u.name);
         const ironedOrders = orders.filter(o => o.workshopTasks && o.workshopTasks.ironedBy === u.name);
         const stitchedOrders = orders.filter(o => o.workshopTasks && o.workshopTasks.stitchedBy === u.name);

         const washedCount = washedOrders.length;
         const ironedCount = ironedOrders.length;
         const stitchedCount = stitchedOrders.length;
         const totalCount = washedCount + ironedCount + stitchedCount;

         return {
           name: u.name,
           washedCount,
           ironedCount,
           stitchedCount,
           totalCount
         };
       }).filter(d => d.totalCount > 0); // Only include staff with activity
    }
    else if (reportType === 'service_revenue') {
       const dbServices = await LaundryService.find();
       const orders = await Order.find(orderFilter);
       const groups = {};
       
       const defaultServices = dbServices.length > 0
         ? dbServices.map(s => s.name)
         : ['Normal Ironing', 'Wash & Iron', 'Express Ironing', 'Express Wash & Iron'];
         
       defaultServices.forEach(name => {
         groups[name] = { service: name, count: 0, revenue: 0 };
       });

       orders.forEach(o => {
         const s = normalizeServiceName(o.serviceType || o.service, dbServices);
         if (!groups[s]) groups[s] = { service: s, count: 0, revenue: 0 };
         groups[s].count += 1;
         groups[s].revenue += (Number(o.totalAmount || o.amount) || 0);
       });
       data = Object.values(groups);
    }
    else if (reportType === 'garment_stats') {
       const orders = await Order.find(orderFilter);
       const groups = {};
       orders.forEach(o => {
         const serviceLower = (o.serviceType || 'Normal').toLowerCase();
         const isExpress = serviceLower.includes('express');
         if (parameter === 'Express' && !isExpress) return;
         if (parameter === 'Normal' && isExpress) return;

         if (o.itemDetails) {
           o.itemDetails.forEach(it => {
             if (parameter && parameter !== 'All' && parameter !== 'Express' && parameter !== 'Normal' && it.name !== parameter) return;
             if (!groups[it.name]) groups[it.name] = { name: it.name, qty: 0, revenue: 0 };
             groups[it.name].qty += it.quantity;
             groups[it.name].revenue += it.quantity * it.unitPrice;
           });
         }
       });
       data = Object.values(groups).sort((a, b) => b.qty - a.qty);
    }
    else if (reportType === 'carpet_blanket_report' || reportType === 'carpets_and_blankets') {
       const orders = await Order.find(orderFilter)
         .populate('customer')
         .populate('branchId')
         .sort({ date: -1, createdAt: -1 })
         .lean();

       const rows = orders.map((o) => {
         const c = o.customer || {};
         const validCustNo = (c.customerNo && c.customerNo !== 'Auto-generated') ? c.customerNo : '';
         const custIdStr = c._id ? c._id.toString() : '';
         const displayCust = validCustNo || (custIdStr ? custIdStr.slice(-6) : '—');

         const autoNo = o.number || '—';
         const manualNo = o.manualNo || o.manualInvoiceNo || (o.notes && o.notes.match(/manual[:\s#]*([^\s,;]+)/i)?.[1]) || '—';

         const isPaid = o.paymentStatus === 'Paid';
         const total = Number(o.totalAmount || o.amount || 0);
         const paid = Number(o.amountPaid !== undefined && o.amountPaid !== null ? o.amountPaid : (isPaid ? total : 0));

         let carpetCount = 0;
         let blanketCount = 0;
         let bedSheetCount = 0;

         (o.itemDetails || []).forEach((it) => {
           const name = `${it.name || ''} ${it.nameAr || ''}`.toLowerCase();
           const qty = Number(it.quantity) || 1;
           if (/carpet|sajjad|rug|mat|سجاد|موكيت|سجادة/i.test(name)) {
             carpetCount += qty;
           } else if (/blanket|comforter|quilt|duvet|بطانية|بطانيه|لحاف|كمفرتر/i.test(name)) {
             blanketCount += qty;
           } else if (/bed\s*sheet|bedsheet|sheet|linen|شرشف|شراشف|غطاء\s*سرير|كفر/i.test(name)) {
             bedSheetCount += qty;
           }
         });

         const isSubscribed = Boolean(c.isSubscriber || Number(c.insuranceAmount || 0) >= 20);
         const mVal = isSubscribed ? 1 : 0;

         const area = c.areaName || o.areaName || '—';
         const part = c.partNo || c.block || '—';
         const street = c.street || '—';
         const jaddah = c.jadda || '—';
         const hom = c.houseNo || '—';
         const floor = c.levelNo || c.floor || '—';
         const flat = c.flatNo || '—';

         // SR = branch name
         const sr = (o.branchId && o.branchId.name) ? o.branchId.name : (o.branchName || (req.targetBranchObj ? req.targetBranchObj.name : '—'));

         // Add number = PACI number
         const addNo = c.paciNo || c.automaticAddressNo || '0';

         return {
           id: o._id,
           cust: displayCust,
           customerName: o.customerName || c.name || 'Unknown',
           phone: c.phone || '—',
           manualNo,
           autoNo,
           payed: paid,
           k: carpetCount,
           c: blanketCount,
           besh: bedSheetCount,
           m: mVal,
           isSubscriber: isSubscribed,
           area,
           part,
           street,
           jaddah,
           hom,
           floor,
           flat,
           sr,
           amount: total,
           addNo,
           status: o.status || 'Waiting',
           paymentStatus: o.paymentStatus || 'Pending',
           deliveryType: o.deliveryType || 'Home Delivery',
           date: o.date || (o.createdAt ? new Date(o.createdAt).toISOString().slice(0, 10) : '')
         };
       });

       let filteredRows = rows;
       if (parameter && parameter !== 'All') {
         if (parameter === 'Carpets & Blankets Only') {
           filteredRows = rows.filter((r) => r.k > 0 || r.c > 0 || r.besh > 0);
         } else if (parameter === 'Carpets Only (K)') {
           filteredRows = rows.filter((r) => r.k > 0);
         } else if (parameter === 'Blankets Only (C)') {
           filteredRows = rows.filter((r) => r.c > 0);
         } else if (parameter === 'Bed Sheets Only (Be&sh)') {
           filteredRows = rows.filter((r) => r.besh > 0);
         } else if (parameter === 'Subscribed (M)' || parameter === 'Subscribed Only (M)') {
           filteredRows = rows.filter((r) => r.m === 1);
         } else if (parameter === 'Paid' || parameter === 'Paid Only') {
           filteredRows = rows.filter((r) => r.paymentStatus === 'Paid');
         } else if (parameter === 'Unpaid' || parameter === 'Unpaid Only') {
           filteredRows = rows.filter((r) => r.paymentStatus !== 'Paid');
         } else if (parameter === 'Home Delivery Only') {
           filteredRows = rows.filter((r) => r.deliveryType === 'Home Delivery');
         }
       }

       data = filteredRows;
    }
    
    res.json({ data });
  } catch (error) {
    console.error('Reports Generate Error:', error);
    require('fs').writeFileSync('report_error.log', error.stack || error.toString());
    res.status(500).json({ message: 'Internal server error' });
  }
});

module.exports = router;
