const mongoose = require('mongoose');

const orderItemSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  nameAr: {
    type: String
  },
  quantity: {
    type: Number,
    required: true
  },
  unitPrice: {
    type: Number,
    required: true
  },
  modifiers: {
    type: String
  }
});

const timelineNodeSchema = new mongoose.Schema({
  status: {
    type: String,
    required: true
  },
  date: {
    type: String,
    required: true
  },
  time: {
    type: String,
    required: true
  },
  updatedBy: {
    type: String,
    required: true
  },
  comment: {
    type: String
  }
});

const orderSchema = new mongoose.Schema({
  number: {
    type: String,
    required: true,
    unique: true
  },
  manualNo: {
    type: String,
    trim: true,
    default: ''
  },
  manualInvoiceNo: {
    type: String,
    trim: true,
    default: ''
  },
  customer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Customer',
    required: true
  },
  customerName: {
    type: String,
    required: true
  },
  serviceType: {
    type: String,
    required: true
  },
  status: {
    type: String,
    enum: [
      'Waiting', 'Preparing in shop', 'Preparing in workshop', 'Ironing', 'Washing',
      'Ready', 'Ready for delivery', 'Ready for shop', 'With Driver', 
      'Delivered', 'Hold', 'Return', 'Store', 'Store 1', 'Store 2', 'In Store', 'In Workshop', 'Cancelled'
    ],
    default: 'Waiting'
  },
  paymentStatus: {
    type: String,
    enum: ['Pending', 'Paid', 'Partial', 'Overdue'],
    default: 'Pending'
  },
  paymentMethod: {
    type: String,
    default: 'Cash'
  },
  shift: {
    type: String,
    default: 'Morning'
  },
  amount: {
    type: Number,
    required: true
  },
  tax: {
    type: Number,
    required: true
  },
  totalAmount: {
    type: Number,
    required: true
  },
  discountAmount: {
    type: Number,
    default: 0.0
  },
  freeBalanceUsed: {
    type: Number,
    default: 0.0
  },
  amountPaid: {
    type: Number,
    default: 0.0
  },
  date: {
    type: String,
    required: true
  },
  pickupDate: {
    type: String
  },
  deliveryDate: {
    type: String
  },
  expectedDeliveryTime: {
    type: String
  },
  deliveryType: {
    type: String,
    enum: ['Branch Pickup', 'Home Delivery'],
    default: 'Branch Pickup'
  },
  notes: {
    type: String
  },
  packaging: {
    type: String,
    enum: ['Normal', 'Folded'],
    default: 'Normal'
  },
  createdBy: {
    type: String,
    required: true
  },
  branchId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Branch',
    required: true
  },
  itemDetails: [orderItemSchema],
  timeline: [timelineNodeSchema],
  sharedBranches: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Branch'
  }],
  transferredTo: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Branch'
  },
  transferredBranchName: {
    type: String
  },
  transferredAt: {
    type: Date
  },
  transferredBy: {
    type: String
  },
  workshopTasks: {
    washedBy: { type: String, default: '' },
    ironedBy: { type: String, default: '' },
    stitchedBy: { type: String, default: '' }
  },
  isEdited: {
    type: Boolean,
    default: false
  },
  editedAt: {
    type: Date
  },
  editedBy: {
    type: String
  }
}, { timestamps: true });

module.exports = mongoose.model('Order', orderSchema);
